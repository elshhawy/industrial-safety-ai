"""Industrial Safety AI backend."""
